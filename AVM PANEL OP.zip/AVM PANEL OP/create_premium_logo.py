from PIL import Image, ImageDraw, ImageFont, ImageFilter

# Create a new premium logo
def create_premium_logo():
    # Create a new image with transparent background
    size = (200, 200)
    img = Image.new('RGBA', size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    
    # Center coordinates
    center_x, center_y = size[0] // 2, size[1] // 2
    
    # Create gradient background circle
    for i in range(80, 0, -1):
        alpha = int(255 * (1 - i / 80))
        color = (
            min(255, 120 + i),  # R
            min(255, 119 + i // 2),  # G
            min(255, 198 + i // 3),  # B
            alpha
        )
        draw.ellipse([center_x - i, center_y - i, center_x + i, center_y + i], fill=color)
    
    # Add golden glow effect
    for i in range(70, 50, -2):
        alpha = int(100 * (1 - (i - 50) / 20))
        color = (255, 215, 0, alpha)
        draw.ellipse([center_x - i, center_y - i, center_x + i, center_y + i], fill=color)
    
    # Create stylized "AVM" text
    try:
        # Try to use a nice font, fallback to default if not available
        font_large = ImageFont.truetype("arial.ttf", 48)
        font_small = ImageFont.truetype("arial.ttf", 24)
    except:
        font_large = ImageFont.load_default()
        font_small = ImageFont.load_default()
    
    # Add "AVM" text with shadow effect
    text = "AVM"
    
    # Text shadow
    shadow_offset = 3
    draw.text((center_x - 45 + shadow_offset, center_y - 25 + shadow_offset), text, 
              fill=(0, 0, 0, 180), font=font_large)
    
    # Main text with gradient effect (simulate with multiple layers)
    for i in range(3):
        offset = i * 2
        color = (255 - offset * 10, 215 - offset * 5, 0 + offset * 20)
        draw.text((center_x - 45 - offset, center_y - 25 - offset), text, 
              fill=color, font=font_large)
    
    # Add "PANEL" text below
    panel_text = "PANEL"
    draw.text((center_x - 35, center_y + 20), panel_text, 
              fill=(255, 255, 255, 200), font=font_small)
    
    # Add decorative elements
    # Top decorative line
    draw.line([center_x - 60, center_y - 50, center_x + 60, center_y - 50], 
             fill=(255, 215, 0, 150), width=2)
    
    # Bottom decorative line
    draw.line([center_x - 60, center_y + 50, center_x + 60, center_y + 50], 
             fill=(255, 215, 0, 150), width=2)
    
    # Add corner accents
    accent_size = 10
    corners = [
        (center_x - 70, center_y - 70),  # Top-left
        (center_x + 70, center_y - 70),  # Top-right
        (center_x - 70, center_y + 70),  # Bottom-left
        (center_x + 70, center_y + 70),  # Bottom-right
    ]
    
    for x, y in corners:
        # Draw small golden squares at corners
        draw.rectangle([x - accent_size//2, y - accent_size//2, x + accent_size//2, y + accent_size//2], 
                      fill=(255, 215, 0, 200))
    
    # Apply blur effect for softness
    img = img.filter(ImageFilter.GaussianBlur(radius=0.5))
    
    # Save the logo
    img.save('static/img/logo.png', 'PNG')
    print("Premium logo created successfully!")

if __name__ == "__main__":
    create_premium_logo()
