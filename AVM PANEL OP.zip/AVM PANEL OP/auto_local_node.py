#!/usr/bin/env python3
"""
Automatic Local Node Creation for AVM Panel
Detects VPS environment and creates local node automatically
"""

import os
import sys
import json
import sqlite3
import subprocess
import requests
import time
import logging
from datetime import datetime
import socket
import platform

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('auto_node.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class VPSDetector:
    """Detects if the panel is running on a VPS"""
    
    @staticmethod
    def is_vps_environment():
        """Check if running in VPS environment"""
        indicators = []
        
        # Check for virtualization indicators
        try:
            # Check DMI product name
            if platform.system() == "Linux":
                try:
                    with open('/sys/class/dmi/id/product_name', 'r') as f:
                        product_name = f.read().strip().lower()
                        vps_indicators = ['virtual', 'vmware', 'virtualbox', 'kvm', 'xen', 'hyper-v']
                        if any(indicator in product_name for indicator in vps_indicators):
                            indicators.append(f"Virtualization detected: {product_name}")
                except:
                    pass
                
                # Check for common VPS providers
                try:
                    with open('/sys/class/dmi/id/sys_vendor', 'r') as f:
                        sys_vendor = f.read().strip().lower()
                        vps_providers = ['digitalocean', 'vultr', 'linode', 'aws', 'google', 'microsoft', 'oracle']
                        if any(provider in sys_vendor for provider in vps_providers):
                            indicators.append(f"VPS provider detected: {sys_vendor}")
                except:
                    pass
                
                # Check cloud-init presence
                if os.path.exists('/etc/cloud/cloud.cfg'):
                    indicators.append("Cloud-init detected")
                
                # Check for common VPS environment variables
                vps_env_vars = ['DIGITALOCEAN', 'VULTR', 'LINODE', 'AWS', 'GCP', 'AZURE']
                for env_var in vps_env_vars:
                    if any(env_var in key for key in os.environ):
                        indicators.append(f"VPS environment variable: {env_var}")
                
                # Check for public IP (not localhost)
                try:
                    response = requests.get('https://api.ipify.org?format=json', timeout=5)
                    if response.status_code == 200:
                        public_ip = response.json().get('ip')
                        if public_ip and not public_ip.startswith('127.') and not public_ip.startswith('192.168.') and not public_ip.startswith('10.'):
                            indicators.append(f"Public IP detected: {public_ip}")
                except:
                    pass
                
                # Check for typical VPS port availability
                common_vps_ports = [80, 443, 22, 8080]
                for port in common_vps_ports:
                    if VPSDetector.is_port_open(port):
                        indicators.append(f"Common VPS port {port} is open")
                        break
                        
        except Exception as e:
            logger.error(f"Error detecting VPS environment: {e}")
        
        logger.info(f"VPS detection indicators: {indicators}")
        return len(indicators) >= 2  # Require at least 2 indicators
    
    @staticmethod
    def is_port_open(port):
        """Check if a port is open"""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(1)
            result = sock.connect_ex(('127.0.0.1', port))
            sock.close()
            return result == 0
        except:
            return False

class SystemResourceMonitor:
    """Monitor system resources for the local node"""
    
    @staticmethod
    def get_system_info():
        """Get comprehensive system information"""
        try:
            import psutil
            
            # CPU info
            cpu_count = psutil.cpu_count()
            cpu_percent = psutil.cpu_percent(interval=1)
            
            # Memory info
            memory = psutil.virtual_memory()
            memory_total = memory.total
            memory_available = memory.available
            memory_percent = memory.percent
            
            # Disk info
            disk = psutil.disk_usage('/')
            disk_total = disk.total
            disk_free = disk.free
            disk_percent = disk.percent
            
            # Network info
            try:
                response = requests.get('https://api.ipify.org?format=json', timeout=5)
                public_ip = response.json().get('ip') if response.status_code == 200 else 'Unknown'
            except:
                public_ip = 'Unknown'
            
            # Get local IP
            local_ip = socket.gethostbyname(socket.gethostname())
            
            system_info = {
                'cpu': {
                    'cores': cpu_count,
                    'usage_percent': cpu_percent
                },
                'memory': {
                    'total_mb': memory_total // (1024 * 1024),
                    'available_mb': memory_available // (1024 * 1024),
                    'usage_percent': memory_percent
                },
                'disk': {
                    'total_gb': disk_total // (1024 * 1024 * 1024),
                    'free_gb': disk_free // (1024 * 1024 * 1024),
                    'usage_percent': disk_percent
                },
                'network': {
                    'public_ip': public_ip,
                    'local_ip': local_ip
                },
                'system': {
                    'platform': platform.system(),
                    'hostname': socket.gethostname(),
                    'uptime': time.time() - psutil.boot_time()
                }
            }
            
            return system_info
            
        except ImportError:
            logger.error("psutil not installed. Installing...")
            try:
                subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'psutil'])
                return SystemResourceMonitor.get_system_info()
            except:
                logger.error("Failed to install psutil")
                return None
        except Exception as e:
            logger.error(f"Error getting system info: {e}")
            return None

class LocalNodeManager:
    """Manage local node creation and configuration"""
    
    def __init__(self, db_path='avm.db'):
        self.db_path = db_path
        self.node_id = 'local-node-1'
        self.node_name = 'Local Node'
        
    def create_local_node(self):
        """Create local node in database"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                # Check if local node already exists
                cursor.execute('SELECT id FROM nodes WHERE id = ?', (self.node_id,))
                if cursor.fetchone():
                    logger.info("Local node already exists")
                    return False
                
                # Get system information
                system_info = SystemResourceMonitor.get_system_info()
                if not system_info:
                    logger.error("Failed to get system information")
                    return False
                
                # Create local node entry
                cursor.execute('''
                    INSERT INTO nodes (
                        id, name, location, ip, status, created_at, updated_at,
                        cpu_cores, memory_mb, disk_gb, cpu_usage, memory_usage, disk_usage
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (
                    self.node_id,
                    self.node_name,
                    'Local VPS',
                    system_info['network']['public_ip'],
                    'online',
                    datetime.now().isoformat(),
                    datetime.now().isoformat(),
                    system_info['cpu']['cores'],
                    system_info['memory']['total_mb'],
                    system_info['disk']['total_gb'],
                    system_info['cpu']['usage_percent'],
                    system_info['memory']['usage_percent'],
                    system_info['disk']['usage_percent']
                ))
                
                conn.commit()
                logger.info(f"Local node created successfully: {self.node_id}")
                return True
                
        except Exception as e:
            logger.error(f"Error creating local node: {e}")
            return False
    
    def update_node_status(self):
        """Update local node status and resource usage"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                # Get current system info
                system_info = SystemResourceMonitor.get_system_info()
                if not system_info:
                    return False
                
                # Update node status
                cursor.execute('''
                    UPDATE nodes SET
                        status = ?, updated_at = ?,
                        cpu_usage = ?, memory_usage = ?, disk_usage = ?,
                        ip = ?
                    WHERE id = ?
                ''', (
                    'online',
                    datetime.now().isoformat(),
                    system_info['cpu']['usage_percent'],
                    system_info['memory']['usage_percent'],
                    system_info['disk']['usage_percent'],
                    system_info['network']['public_ip'],
                    self.node_id
                ))
                
                conn.commit()
                logger.debug("Local node status updated")
                return True
                
        except Exception as e:
            logger.error(f"Error updating node status: {e}")
            return False
    
    def create_local_containers(self):
        """Create sample containers on local node"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                # Check if containers already exist for local node
                cursor.execute('SELECT id FROM containers WHERE node_id = ?', (self.node_id,))
                if cursor.fetchone():
                    logger.info("Local containers already exist")
                    return True
                
                # Create sample containers
                sample_containers = [
                    {
                        'id': f'{self.node_id}-web-1',
                        'name': 'Web Server 1',
                        'os': 'ubuntu:22.04',
                        'cpu_cores': 1,
                        'memory_mb': 1024,
                        'disk_gb': 20,
                        'status': 'running'
                    },
                    {
                        'id': f'{self.node_id}-db-1',
                        'name': 'Database Server 1',
                        'os': 'ubuntu:22.04',
                        'cpu_cores': 2,
                        'memory_mb': 2048,
                        'disk_gb': 50,
                        'status': 'running'
                    }
                ]
                
                for container in sample_containers:
                    cursor.execute('''
                        INSERT INTO containers (
                            id, name, node_id, os_template, cpu_cores, memory_mb,
                            disk_gb, status, created_at, updated_at
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ''', (
                        container['id'],
                        container['name'],
                        self.node_id,
                        container['os'],
                        container['cpu_cores'],
                        container['memory_mb'],
                        container['disk_gb'],
                        container['status'],
                        datetime.now().isoformat(),
                        datetime.now().isoformat()
                    ))
                
                conn.commit()
                logger.info(f"Created {len(sample_containers)} sample containers")
                return True
                
        except Exception as e:
            logger.error(f"Error creating local containers: {e}")
            return False

class AutoNodeService:
    """Main service for automatic local node management"""
    
    def __init__(self):
        self.node_manager = LocalNodeManager()
        self.running = False
        
    def start(self):
        """Start the auto node service"""
        logger.info("Starting Auto Node Service...")
        
        # Check if running on VPS
        if not VPSDetector.is_vps_environment():
            logger.info("Not running on VPS, skipping local node creation")
            return
        
        logger.info("VPS environment detected, creating local node...")
        
        # Create local node
        if self.node_manager.create_local_node():
            # Create sample containers
            self.node_manager.create_local_containers()
            
            # Start monitoring loop
            self.running = True
            self.monitoring_loop()
        else:
            logger.error("Failed to create local node")
    
    def monitoring_loop(self):
        """Continuous monitoring loop"""
        logger.info("Starting resource monitoring loop...")
        
        while self.running:
            try:
                # Update node status every 30 seconds
                self.node_manager.update_node_status()
                time.sleep(30)
                
            except KeyboardInterrupt:
                logger.info("Stopping monitoring loop...")
                self.running = False
                break
            except Exception as e:
                logger.error(f"Error in monitoring loop: {e}")
                time.sleep(5)

def main():
    """Main entry point"""
    logger.info("Auto Local Node Service starting...")
    
    try:
        service = AutoNodeService()
        service.start()
    except Exception as e:
        logger.error(f"Fatal error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
