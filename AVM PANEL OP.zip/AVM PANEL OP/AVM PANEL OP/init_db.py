#!/usr/bin/env python3
"""
Initialize database with Discord tables
"""
import sqlite3
import os
import sys
from datetime import datetime

def init_database():
    """Initialize database with all tables including Discord tables"""
    db_path = "avm.db"
    
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Discord Deployments table
        cursor.execute('''CREATE TABLE IF NOT EXISTS discord_deployments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            deployment_id TEXT UNIQUE NOT NULL,
            user_id INTEGER NOT NULL,
            vps_id INTEGER,
            discord_user_id TEXT,
            discord_username TEXT,
            command TEXT NOT NULL,
            status TEXT DEFAULT 'pending',
            progress TEXT DEFAULT '0%',
            message TEXT,
            logs TEXT,
            started_at TEXT,
            completed_at TEXT,
            created_at TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY(vps_id) REFERENCES vps(id) ON DELETE SET NULL
        )''')
        
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_discord_deployments_user_id ON discord_deployments(user_id)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_discord_deployments_status ON discord_deployments(status)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_discord_deployments_deployment_id ON discord_deployments(deployment_id)')
        
        # Discord Commands table
        cursor.execute('''CREATE TABLE IF NOT EXISTS discord_commands (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            command_name TEXT UNIQUE NOT NULL,
            description TEXT,
            command_template TEXT NOT NULL,
            requires_vps INTEGER DEFAULT 1,
            admin_only INTEGER DEFAULT 0,
            enabled INTEGER DEFAULT 1,
            usage_count INTEGER DEFAULT 0,
            created_at TEXT NOT NULL
        )''')
        
        # Insert default Discord commands
        default_commands = [
            ('deploy', 'Deploy a new VPS', '!deploy <os> <cpu> <ram> <disk>', 1, 0, 1),
            ('start', 'Start a VPS', '!start <vps_name>', 1, 0, 1),
            ('stop', 'Stop a VPS', '!stop <vps_name>', 1, 0, 1),
            ('restart', 'Restart a VPS', '!restart <vps_name>', 1, 0, 1),
            ('delete', 'Delete a VPS', '!delete <vps_name>', 1, 0, 1),
            ('status', 'Check VPS status', '!status [vps_name]', 1, 0, 1),
            ('list', 'List all VPS', '!list', 1, 0, 1),
            ('console', 'Open console to VPS', '!console <vps_name>', 1, 0, 1),
            ('help', 'Show available commands', '!help', 0, 0, 1),
        ]
        
        cursor.execute('SELECT COUNT(*) FROM discord_commands')
        if cursor.fetchone()[0] == 0:
            for cmd in default_commands:
                cursor.execute('''INSERT INTO discord_commands 
                    (command_name, description, command_template, requires_vps, admin_only, enabled, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?)''', (*cmd, datetime.now().isoformat()))
        
        conn.commit()
        conn.close()
        
        print("SUCCESS: Database initialized with Discord tables")
        return True
        
    except Exception as e:
        print(f"ERROR: Database initialization failed: {e}")
        return False

if __name__ == "__main__":
    success = init_database()
    sys.exit(0 if success else 1)
