#!/usr/bin/env python3
"""
Test Discord GIF background implementation in dashboard
"""
import os
import re

def test_dashboard_discord_background():
    """Test Discord GIF background is properly implemented in dashboard"""
    print("=== Testing Dashboard Discord GIF Background ===")
    
    dashboard_path = "templates/dashboard.html"
    if not os.path.exists(dashboard_path):
        print("ERROR: dashboard.html not found")
        return False
    
    with open(dashboard_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Check for Discord GIF URL
    discord_url = "https://cdn.discordapp.com/attachments/1462051582408396822/1491390316362731570/48f1872171296936c81ac44a2647d534.gif"
    if discord_url in content:
        print("SUCCESS: Discord GIF URL found in dashboard.html")
    else:
        print("ERROR: Discord GIF URL not found in dashboard")
        return False
    
    # Check for dashboard container background
    if ".dashboard-container {" in content:
        print("SUCCESS: Dashboard container selector found")
    else:
        print("ERROR: Dashboard container selector not found")
        return False
    
    # Check for background properties in dashboard container
    background_checks = [
        ("url('https://cdn.discordapp.com/attachments/1462051582408396822/1491390316362731570/48f1872171296936c81ac44a2647d534.gif", "Discord GIF background URL"),
        ("center/cover no-repeat fixed", "Background sizing and positioning"),
        ("background-blend-mode: overlay", "Background blend mode"),
        ("animation: discordDashboardPulse", "Dashboard pulse animation"),
    ]
    
    for check, description in background_checks:
        if check in content:
            print(f"SUCCESS: {description} found")
        else:
            print(f"ERROR: {description} missing")
            return False
    
    # Check for keyframes animation
    if "@keyframes discordDashboardPulse" in content:
        print("SUCCESS: Dashboard pulse animation keyframes found")
    else:
        print("ERROR: Dashboard pulse animation keyframes not found")
        return False
    
    # Check for animation properties
    animation_checks = [
        ("background-size: 100%", "Initial background size"),
        ("background-size: 105%", "Scaled background size"),
        ("opacity: 1", "Initial opacity"),
        ("opacity: 0.95", "Faded opacity"),
    ]
    
    for check, description in animation_checks:
        if check in content:
            print(f"SUCCESS: {description} found")
        else:
            print(f"ERROR: {description} missing")
            return False
    
    return True

def test_dashboard_background_structure():
    """Test dashboard background structure is valid"""
    print("\n=== Testing Dashboard Background Structure ===")
    
    dashboard_path = "templates/dashboard.html"
    with open(dashboard_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Check for proper CSS structure
    if "background:" in content and "}" in content:
        print("SUCCESS: CSS background structure appears valid")
    else:
        print("ERROR: CSS background structure invalid")
        return False
    
    # Check for multiple background layers
    background_layers = content.count("radial-gradient") + content.count("linear-gradient")
    if background_layers >= 4:
        print(f"SUCCESS: Found {background_layers} background gradient layers")
    else:
        print(f"WARNING: Only found {background_layers} background gradient layers")
    
    # Check for overlay blend mode
    if "background-blend-mode: overlay" in content:
        print("SUCCESS: Overlay blend mode properly configured")
    else:
        print("ERROR: Overlay blend mode missing")
        return False
    
    return True

def main():
    """Run dashboard background tests"""
    print("Dashboard Discord GIF Background Test Suite")
    print("=" * 50)
    
    tests = [
        test_dashboard_discord_background,
        test_dashboard_background_structure,
    ]
    
    results = []
    for test in tests:
        try:
            result = test()
            results.append(result)
        except Exception as e:
            print(f"ERROR: Test failed with exception: {e}")
            results.append(False)
    
    print("\n" + "=" * 50)
    print("Test Results Summary:")
    print("=" * 50)
    
    passed = sum(results)
    total = len(results)
    
    print(f"Tests Passed: {passed}/{total}")
    
    if passed == total:
        print("SUCCESS: Dashboard Discord GIF background is working correctly!")
        print("\nFeatures implemented:")
        print("  - Discord GIF as dashboard background")
        print("  - Pulse animation effect (8s cycle)")
        print("  - Background blend mode for proper layering")
        print("  - Fixed background attachment")
        print("  - Responsive background sizing")
        print("  - Opacity animation for subtle effect")
        return 0
    else:
        print("WARNING: Some tests failed. Check the output above for details.")
        return 1

if __name__ == "__main__":
    import sys
    sys.exit(main())
