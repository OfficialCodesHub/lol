#!/usr/bin/env python3
"""
Test Discord GIF background implementation on login and register pages
"""
import os
import re

def test_login_page_background():
    """Test Discord GIF background is properly implemented in login page"""
    print("=== Testing Login Page Discord GIF Background ===")
    
    login_path = "templates/login.html"
    if not os.path.exists(login_path):
        print("ERROR: login.html not found")
        return False
    
    with open(login_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Check for Discord GIF URL
    discord_url = "https://cdn.discordapp.com/attachments/1462051582408396822/1491390316362731570/48f1872171296936c81ac44a2647d534.gif"
    if discord_url in content:
        print("SUCCESS: Discord GIF URL found in login.html")
    else:
        print("ERROR: Discord GIF URL not found in login page")
        return False
    
    # Check for login container background
    if ".login-container {" in content:
        print("SUCCESS: Login container selector found")
    else:
        print("ERROR: Login container selector not found")
        return False
    
    # Check for background properties
    background_checks = [
        ("url('https://cdn.discordapp.com/attachments/1462051582408396822/1491390316362731570/48f1872171296936c81ac44a2647d534.gif", "Discord GIF background URL"),
        ("center/cover no-repeat fixed", "Background sizing and positioning"),
        ("background-blend-mode: overlay", "Background blend mode"),
        ("animation: discordLoginPulse", "Login pulse animation"),
    ]
    
    for check, description in background_checks:
        if check in content:
            print(f"SUCCESS: {description} found")
        else:
            print(f"ERROR: {description} missing")
            return False
    
    # Check for keyframes animation
    if "@keyframes discordLoginPulse" in content:
        print("SUCCESS: Login pulse animation keyframes found")
    else:
        print("ERROR: Login pulse animation keyframes not found")
        return False
    
    return True

def test_register_page_background():
    """Test Discord GIF background is properly implemented in register page"""
    print("\n=== Testing Register Page Discord GIF Background ===")
    
    register_path = "templates/register.html"
    if not os.path.exists(register_path):
        print("ERROR: register.html not found")
        return False
    
    with open(register_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Check for Discord GIF URL
    discord_url = "https://cdn.discordapp.com/attachments/1462051582408396822/1491390316362731570/48f1872171296936c81ac44a2647d534.gif"
    if discord_url in content:
        print("SUCCESS: Discord GIF URL found in register.html")
    else:
        print("ERROR: Discord GIF URL not found in register page")
        return False
    
    # Check for register container background
    if ".register-container {" in content:
        print("SUCCESS: Register container selector found")
    else:
        print("ERROR: Register container selector not found")
        return False
    
    # Check for background properties
    background_checks = [
        ("url('https://cdn.discordapp.com/attachments/1462051582408396822/1491390316362731570/48f1872171296936c81ac44a2647d534.gif", "Discord GIF background URL"),
        ("center/cover no-repeat fixed", "Background sizing and positioning"),
        ("background-blend-mode: overlay", "Background blend mode"),
        ("animation: discordRegisterPulse", "Register pulse animation"),
    ]
    
    for check, description in background_checks:
        if check in content:
            print(f"SUCCESS: {description} found")
        else:
            print(f"ERROR: {description} missing")
            return False
    
    # Check for keyframes animation
    if "@keyframes discordRegisterPulse" in content:
        print("SUCCESS: Register pulse animation keyframes found")
    else:
        print("ERROR: Register pulse animation keyframes not found")
        return False
    
    return True

def test_auth_pages_consistency():
    """Test consistency between login and register pages"""
    print("\n=== Testing Auth Pages Consistency ===")
    
    login_path = "templates/login.html"
    register_path = "templates/register.html"
    
    with open(login_path, 'r', encoding='utf-8') as f:
        login_content = f.read()
    
    with open(register_path, 'r', encoding='utf-8') as f:
        register_content = f.read()
    
    # Check for consistent Discord URL
    discord_url = "https://cdn.discordapp.com/attachments/1462051582408396822/1491390316362731570/48f1872171296936c81ac44a2647d534.gif"
    login_has_url = discord_url in login_content
    register_has_url = discord_url in register_content
    
    if login_has_url and register_has_url:
        print("SUCCESS: Both pages have consistent Discord GIF URL")
    else:
        print("ERROR: Inconsistent Discord GIF URL between pages")
        return False
    
    # Check for consistent background properties
    consistent_props = [
        "center/cover no-repeat fixed",
        "background-blend-mode: overlay",
    ]
    
    for prop in consistent_props:
        if prop in login_content and prop in register_content:
            print(f"SUCCESS: Consistent {prop.split(':')[0]} property")
        else:
            print(f"ERROR: Inconsistent {prop.split(':')[0]} property")
            return False
    
    # Check for unique animation names
    if "discordLoginPulse" in login_content and "discordRegisterPulse" in register_content:
        print("SUCCESS: Unique animation names for each page")
    else:
        print("ERROR: Animation names not unique or missing")
        return False
    
    return True

def main():
    """Run auth pages background tests"""
    print("Auth Pages Discord GIF Background Test Suite")
    print("=" * 50)
    
    tests = [
        test_login_page_background,
        test_register_page_background,
        test_auth_pages_consistency,
    ]
    
    results = []
    for test in tests:
        try:
            result = test()
            results.append(result)
        except Exception as e:
            print(f"ERROR: Test failed with exception: {e}")
            results.append(False)
    
    print("\n" + "=" * 50)
    print("Test Results Summary:")
    print("=" * 50)
    
    passed = sum(results)
    total = len(results)
    
    print(f"Tests Passed: {passed}/{total}")
    
    if passed == total:
        print("SUCCESS: Auth pages Discord GIF background is working correctly!")
        print("\nFeatures implemented:")
        print("  - Discord GIF background on login page")
        print("  - Discord GIF background on register page")
        print("  - Unique pulse animations for each page")
        print("  - Background blend mode for proper layering")
        print("  - Fixed background attachment")
        print("  - Responsive background sizing")
        print("  - Consistent styling between pages")
        return 0
    else:
        print("WARNING: Some tests failed. Check the output above for details.")
        return 1

if __name__ == "__main__":
    import sys
    sys.exit(main())
