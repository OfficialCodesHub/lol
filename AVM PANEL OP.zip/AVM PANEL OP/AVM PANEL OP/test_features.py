#!/usr/bin/env python3
"""
Test script to verify Debian OS fix and Discord bot integration
"""
import sqlite3
import os
import sys

def test_debian_os_fix():
    """Test Debian OS options are correctly configured"""
    print("=== Testing Debian OS Fix ===")
    
    # Check if avm.py exists and has correct OS options
    avm_path = "avm.py"
    if not os.path.exists(avm_path):
        print("ERROR: avm.py not found")
        return False
    
    with open(avm_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Check for correct Debian OS format
    debian_checks = [
        '"debian:10"' in content,
        '"debian:11"' in content,
        '"debian:12"' in content,
        '"debian:13"' in content,
        '"images:debian/' not in content,  # Should not have old format
    ]
    
    if all(debian_checks):
        print("SUCCESS: Debian OS options correctly configured")
        return True
    else:
        print("ERROR: Debian OS options not properly configured")
        return False

def test_discord_database_tables():
    """Test Discord database tables exist"""
    print("\n=== Testing Discord Database Tables ===")
    
    db_path = "avm.db"
    if not os.path.exists(db_path):
        print("ERROR: Database not found")
        return False
    
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Check Discord deployments table
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='discord_deployments'")
        if cursor.fetchone():
            print("SUCCESS: discord_deployments table exists")
        else:
            print("ERROR: discord_deployments table missing")
            return False
        
        # Check Discord commands table
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='discord_commands'")
        if cursor.fetchone():
            print("SUCCESS: discord_commands table exists")
        else:
            print("ERROR: discord_commands table missing")
            return False
        
        # Check if default commands are inserted
        cursor.execute("SELECT COUNT(*) FROM discord_commands")
        count = cursor.fetchone()[0]
        if count > 0:
            print(f"SUCCESS: {count} Discord commands found")
        else:
            print("ERROR: No Discord commands found")
            return False
        
        conn.close()
        return True
        
    except Exception as e:
        print(f"ERROR: Database test failed: {e}")
        return False

def test_discord_routes():
    """Test Discord routes exist in avm.py"""
    print("\n=== Testing Discord Routes ===")
    
    avm_path = "avm.py"
    if not os.path.exists(avm_path):
        print("ERROR: avm.py not found")
        return False
    
    with open(avm_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    route_checks = [
        "@app.route('/admin/discord')" in content,
        "def discord_config():" in content,
        "@app.route('/admin/discord/config', methods=['POST'])" in content,
        "def update_discord_config():" in content,
        "@app.route('/admin/discord/deployments')" in content,
        "def get_discord_deployments():" in content,
        "@app.route('/admin/discord/test', methods=['POST'])" in content,
        "def test_discord_bot():" in content,
    ]
    
    if all(route_checks):
        print("SUCCESS: All Discord routes found")
        return True
    else:
        print("ERROR: Some Discord routes missing")
        return False

def test_discord_bot_class():
    """Test Discord bot class exists"""
    print("\n=== Testing Discord Bot Class ===")
    
    avm_path = "avm.py"
    if not os.path.exists(avm_path):
        print("ERROR: avm.py not found")
        return False
    
    with open(avm_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    bot_checks = [
        "class AVMDiscordBot" in content,
        "class DeployCommands" in content,
        "@commands.command(name='deploy')" in content,
        "@commands.command(name='help')" in content,
        "def start_discord_bot():" in content,
        "DISCORD_AVAILABLE" in content,
        "DISCORD_BOT_TOKEN" in content,
        "DISCORD_BOT_ENABLED" in content,
    ]
    
    if all(bot_checks):
        print("SUCCESS: Discord bot implementation found")
        return True
    else:
        print("ERROR: Discord bot implementation incomplete")
        return False

def test_discord_template():
    """Test Discord template exists"""
    print("\n=== Testing Discord Template ===")
    
    template_path = "templates/admin/discord.html"
    if not os.path.exists(template_path):
        print("ERROR: Discord template not found")
        return False
    
    with open(template_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    template_checks = [
        "Discord Bot Configuration" in content,
        "discord_config_form" in content,
        "discord_bot_token" in content,
        "deployment-table" in content,
        "command-list" in content,
    ]
    
    if all(template_checks):
        print("SUCCESS: Discord template found and configured")
        return True
    else:
        print("ERROR: Discord template incomplete")
        return False

def test_dependencies():
    """Test if required dependencies are available"""
    print("\n=== Testing Dependencies ===")
    
    # Test Discord.py
    try:
        import discord
        print("SUCCESS: discord.py available")
        discord_available = True
    except ImportError:
        print("WARNING: discord.py not installed (pip install discord.py)")
        discord_available = False
    
    # Test Flask
    try:
        import flask
        print("SUCCESS: Flask available")
        flask_available = True
    except ImportError:
        print("ERROR: Flask not installed")
        flask_available = False
    
    # Test SQLite
    try:
        import sqlite3
        print("SUCCESS: SQLite available")
        sqlite_available = True
    except ImportError:
        print("ERROR: SQLite not available")
        sqlite_available = False
    
    return flask_available and sqlite_available

def main():
    """Run all tests"""
    print("AVM Panel Feature Test Suite")
    print("=" * 50)
    
    tests = [
        test_debian_os_fix,
        test_discord_database_tables,
        test_discord_routes,
        test_discord_bot_class,
        test_discord_template,
        test_dependencies,
    ]
    
    results = []
    for test in tests:
        try:
            result = test()
            results.append(result)
        except Exception as e:
            print(f"ERROR: Test failed with exception: {e}")
            results.append(False)
    
    print("\n" + "=" * 50)
    print("Test Results Summary:")
    print("=" * 50)
    
    passed = sum(results)
    total = len(results)
    
    print(f"Tests Passed: {passed}/{total}")
    
    if passed == total:
        print("SUCCESS: All tests passed! Features are working correctly.")
        return 0
    else:
        print("WARNING: Some tests failed. Check the output above for details.")
        return 1

if __name__ == "__main__":
    sys.exit(main())
