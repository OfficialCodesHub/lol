#!/usr/bin/env python3
"""
Debug Discord routes and template issues
"""
import os

def debug_discord_routes():
    """Debug Discord routes"""
    print("=== Debugging Discord Routes ===")
    
    avm_path = "avm.py"
    with open(avm_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    routes = [
        "@app.route('/admin/discord')",
        "def discord_config():",
        "@app.route('/admin/discord/config')",
        "def update_discord_config():",
        "@app.route('/admin/discord/deployments')",
        "def get_discord_deployments():",
        "@app.route('/admin/discord/test')",
        "def test_discord_bot():",
    ]
    
    for route in routes:
        if route in content:
            print(f"FOUND: {route}")
        else:
            print(f"MISSING: {route}")
    
    # Find all Discord-related routes
    lines = content.split('\n')
    for i, line in enumerate(lines):
        if '@app.route' in line and 'discord' in line.lower():
            print(f"Line {i+1}: {line.strip()}")

def debug_discord_template():
    """Debug Discord template"""
    print("\n=== Debugging Discord Template ===")
    
    template_path = "templates/admin/discord.html"
    if not os.path.exists(template_path):
        print("ERROR: Template file not found")
        return
    
    with open(template_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    checks = [
        "Discord Bot Configuration",
        "discord_config_form",
        "discord_bot_token",
        "deployment-table",
        "command-list",
    ]
    
    for check in checks:
        if check in content:
            print(f"FOUND: {check}")
        else:
            print(f"MISSING: {check}")
    
    # Show first few lines of template
    lines = content.split('\n')
    print(f"\nTemplate first 10 lines:")
    for i, line in enumerate(lines[:10]):
        print(f"Line {i+1}: {line.strip()}")

if __name__ == "__main__":
    debug_discord_routes()
    debug_discord_template()
