#!/usr/bin/env python3
"""
Test that bouncing animations have been removed from all Discord GIF backgrounds
"""
import os

def test_no_bouncing_animations():
    """Test that no Discord bouncing animations exist in any template"""
    print("=== Testing Static Background Implementation ===")
    
    templates = [
        ("templates/base.html", "Base Template"),
        ("templates/dashboard.html", "Dashboard"),
        ("templates/login.html", "Login"),
        ("templates/register.html", "Register"),
    ]
    
    # Only check for Discord-specific animations
    discord_animations = [
        "discordBgPulse",
        "discordDashboardPulse", 
        "discordLoginPulse",
        "discordRegisterPulse",
        "animation.*discord.*Pulse",
        "@keyframes.*discord.*Pulse",
    ]
    
    all_good = True
    
    for template_path, template_name in templates:
        if not os.path.exists(template_path):
            print(f"ERROR: {template_name} template not found")
            all_good = False
            continue
            
        with open(template_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        print(f"\n--- Checking {template_name} ---")
        
        # Check for Discord GIF URL (should still be there)
        discord_url = "https://cdn.discordapp.com/attachments/1462051582408396822/1491390316362731570/48f1872171296936c81ac44a2647d534.gif"
        if discord_url in content:
            print(f"SUCCESS: Discord GIF URL present")
        else:
            print(f"WARNING: Discord GIF URL missing")
        
        # Check for Discord-specific unwanted animations
        found_animations = []
        for anim in discord_animations:
            if anim in content:
                found_animations.append(anim)
        
        if found_animations:
            print(f"ERROR: Found Discord bouncing animations: {found_animations}")
            all_good = False
        else:
            print(f"SUCCESS: No Discord bouncing animations found")
        
        # Check for Discord background properties based on template type
        if template_name == "Base Template":
            # Base template uses ::before pseudo-element
            required_props = [
                "background-image: url",
                "background-size: cover",
                "background-position: center",
                "background-repeat: no-repeat",
                "background-attachment: fixed",
                "opacity: 0.15",
                "z-index: -1",
            ]
        else:
            # Other templates use container backgrounds
            required_props = [
                "url('https://cdn.discordapp.com/attachments/1462051582408396822/1491390316362731570/48f1872171296936c81ac44a2647d534.gif",
                "center/cover no-repeat fixed",
                "background-blend-mode: overlay",
            ]
        
        missing_props = []
        for prop in required_props:
            if prop not in content:
                missing_props.append(prop)
        
        if missing_props:
            print(f"WARNING: Missing properties: {missing_props}")
        else:
            print(f"SUCCESS: Required background properties present")
    
    return all_good

def test_background_consistency():
    """Test that backgrounds are consistent across pages"""
    print("\n=== Testing Background Consistency ===")
    
    templates = [
        "templates/dashboard.html",
        "templates/login.html", 
        "templates/register.html"
    ]
    
    # Get Discord URL from first template
    with open(templates[0], 'r', encoding='utf-8') as f:
        first_content = f.read()
    
    discord_url = "https://cdn.discordapp.com/attachments/1462051582408396822/1491390316362731570/48f1872171296936c81ac44a2647d534.gif"
    
    consistent = True
    for template_path in templates:
        with open(template_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        if discord_url not in content:
            print(f"ERROR: Inconsistent Discord URL in {template_path}")
            consistent = False
    
    if consistent:
        print("SUCCESS: Discord GIF URL consistent across all pages")
    
    return consistent

def main():
    """Run static background tests"""
    print("Static Background Test Suite")
    print("=" * 50)
    
    tests = [
        test_no_bouncing_animations,
        test_background_consistency,
    ]
    
    results = []
    for test in tests:
        try:
            result = test()
            results.append(result)
        except Exception as e:
            print(f"ERROR: Test failed with exception: {e}")
            results.append(False)
    
    print("\n" + "=" * 50)
    print("Test Results Summary:")
    print("=" * 50)
    
    passed = sum(results)
    total = len(results)
    
    print(f"Tests Passed: {passed}/{total}")
    
    if passed == total:
        print("SUCCESS: Bouncing effects removed! Backgrounds are now static.")
        print("\nFeatures implemented:")
        print("  - Static Discord GIF background (no bouncing)")
        print("  - Consistent background across all pages")
        print("  - Proper background sizing and positioning")
        print("  - Fixed background attachment")
        print("  - Appropriate opacity and z-index")
        return 0
    else:
        print("WARNING: Some bouncing effects may still be present.")
        return 1

if __name__ == "__main__":
    import sys
    sys.exit(main())
