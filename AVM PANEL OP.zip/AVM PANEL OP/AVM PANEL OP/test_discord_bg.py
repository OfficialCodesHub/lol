#!/usr/bin/env python3
"""
Test Discord GIF background implementation
"""
import os
import re

def test_discord_background():
    """Test Discord GIF background is properly implemented"""
    print("=== Testing Discord GIF Background ===")
    
    base_path = "templates/base.html"
    if not os.path.exists(base_path):
        print("ERROR: base.html not found")
        return False
    
    with open(base_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Check for Discord GIF URL
    discord_url = "https://cdn.discordapp.com/attachments/1462051582408396822/1491390316362731570/48f1872171296936c81ac44a2647d534.gif"
    if discord_url in content:
        print("SUCCESS: Discord GIF URL found in base.html")
    else:
        print("ERROR: Discord GIF URL not found")
        return False
    
    # Check for ::before pseudo-element
    if "body::before" in content:
        print("SUCCESS: body::before pseudo-element found")
    else:
        print("ERROR: body::before pseudo-element not found")
        return False
    
    # Check for background properties
    background_properties = [
        ("background-image: url", "background-image"),
        ("background-size: cover", "background-size"),
        ("background-position: center", "background-position"),
        ("background-repeat: no-repeat", "background-repeat"),
        ("background-attachment: fixed", "background-attachment"),
    ]
    
    for check, prop_name in background_properties:
        if check in content:
            print(f"SUCCESS: {prop_name} property found")
        else:
            print(f"ERROR: {prop_name} property missing")
            return False
    
    # Check for animation
    if "discordBgPulse" in content:
        print("SUCCESS: Discord background animation found")
    else:
        print("ERROR: Discord background animation not found")
        return False
    
    # Check for opacity and z-index
    if "opacity: 0.15" in content and "z-index: -1" in content:
        print("SUCCESS: Background opacity and z-index properly set")
    else:
        print("ERROR: Background opacity or z-index missing")
        return False
    
    return True

def test_css_structure():
    """Test CSS structure is valid"""
    print("\n=== Testing CSS Structure ===")
    
    base_path = "templates/base.html"
    with open(base_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Check for duplicate body selectors
    body_matches = re.findall(r'body\s*\{', content)
    if len(body_matches) == 1:
        print("SUCCESS: Only one body selector found")
    else:
        print(f"WARNING: {len(body_matches)} body selectors found")
    
    # Check for proper CSS structure
    if "body {" in content and "}" in content:
        print("SUCCESS: CSS structure appears valid")
        return True
    else:
        print("ERROR: CSS structure invalid")
        return False

def main():
    """Run background tests"""
    print("Discord GIF Background Test Suite")
    print("=" * 50)
    
    tests = [
        test_discord_background,
        test_css_structure,
    ]
    
    results = []
    for test in tests:
        try:
            result = test()
            results.append(result)
        except Exception as e:
            print(f"ERROR: Test failed with exception: {e}")
            results.append(False)
    
    print("\n" + "=" * 50)
    print("Test Results Summary:")
    print("=" * 50)
    
    passed = sum(results)
    total = len(results)
    
    print(f"Tests Passed: {passed}/{total}")
    
    if passed == total:
        print("SUCCESS: Discord GIF background is working correctly!")
        print("\nFeatures implemented:")
        print("  - Discord GIF as animated background")
        print("  - Pulse animation effect")
        print("  - Proper opacity and z-index layering")
        print("  - Fixed background attachment")
        print("  - Responsive background sizing")
        return 0
    else:
        print("WARNING: Some tests failed. Check the output above for details.")
        return 1

if __name__ == "__main__":
    import sys
    sys.exit(main())
