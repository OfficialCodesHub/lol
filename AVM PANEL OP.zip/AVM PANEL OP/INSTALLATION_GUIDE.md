# AVM Panel & Node Installation Guide

## 📋 Table of Contents
1. [System Requirements](#system-requirements)
2. [AVM Panel Installation](#avm-panel-installation)
3. [AVM Node Installation](#avm-node-installation)
4. [Configuration](#configuration)
5. [Starting the Services](#starting-the-services)
6. [Troubleshooting](#troubleshooting)
7. [Security Recommendations](#security-recommendations)

---

## 🔧 System Requirements

### Minimum Requirements
- **OS**: Windows 10/11, Ubuntu 18.04+, CentOS 7+, or Debian 9+
- **RAM**: 2GB minimum, 4GB recommended
- **Storage**: 10GB free space
- **Network**: Stable internet connection
- **Python**: 3.8 or higher
- **LXC/LXD**: For container management (Linux only)

### Recommended Requirements
- **OS**: Ubuntu 20.04 LTS or Windows 11
- **RAM**: 8GB or more
- **Storage**: 50GB+ SSD
- **CPU**: 4+ cores
- **Network**: 100Mbps+ connection

---

## 🚀 AVM Panel Installation

### Step 1: Prerequisites

#### For Windows:
```powershell
# Install Python 3.8+ from python.org
# Verify installation
python --version
pip --version
```

#### For Linux (Ubuntu/Debian):
```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Python and required packages
sudo apt install python3 python3-pip python3-venv git -y

# Install LXC/LXD for container management
sudo apt install lxc lxd -y
sudo usermod -aG lxd $USER
newgrp lxd
```

#### For Linux (CentOS/RHEL):
```bash
# Install EPEL repository
sudo yum install epel-release -y

# Install Python and git
sudo yum install python3 python3-pip git -y

# Install LXC/LXD
sudo yum install lxc lxd -y
sudo usermod -aG lxd $USER
```

### Step 2: Clone and Setup Panel

```bash
# Clone the repository
git clone <repository-url> avm-panel
cd avm-panel

# Create virtual environment (recommended)
python -m venv venv

# Activate virtual environment
# Windows:
venv\Scripts\activate
# Linux/Mac:
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

### Step 3: Database Setup

```bash
# Initialize the database
python init_db.py

# Or create manually:
python -c "
import sqlite3
conn = sqlite3.connect('avm.db')
conn.close()
print('Database created successfully!')
"
```

### Step 4: Environment Configuration

Create a `.env` file in the project root:

```env
# Panel Configuration
PANEL_NAME=AVM Panel
SECRET_KEY=your-secret-key-here
DEBUG_MODE=False
HOST=127.0.0.1
PORT=5000

# Database
DATABASE_PATH=avm.db

# Server Configuration
YOUR_SERVER_IP=your-server-ip
DEFAULT_STORAGE_POOL=default

# Discord OAuth (Optional)
DISCORD_CLIENT_ID=your-discord-client-id
DISCORD_CLIENT_SECRET=your-discord-client-secret
DISCORD_REDIRECT_URI=http://your-domain:5000/auth/discord/callback

# Backup Configuration
AUTO_BACKUP_INTERVAL=24  # hours
BACKUP_PATH=backups/

# Monitoring
STATS_UPDATE_INTERVAL=30  # seconds

# Groq API (Optional)
GROQ_API_URL=https://api.groq.com/openai/v1
DEFAULT_GROQ_MODEL=llama2-70b-4096
GROQ_API_KEY=your-groq-api-key
```

---

## 🖥️ AVM Node Installation

### Step 1: Prerequisites

#### For Linux Only (Node is Linux-specific):
```bash
# Install required packages
sudo apt install python3 python3-pip git lxc lxd -y

# Add user to LXD group
sudo usermod -aG lxd $USER
newgrp lxd

# Initialize LXD (if not already done)
sudo lxd init --auto
```

### Step 2: Clone and Setup Node

```bash
# Clone the node repository (same as panel)
git clone <repository-url> avm-node
cd avm-node

# Create virtual environment
python3 -m venv venv
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

### Step 3: Node Configuration

Create a `config.py` file:

```python
# Node Configuration
NODE_ID = "node-1"
NODE_NAME = "Primary Node"
NODE_LOCATION = "US-East"
NODE_IP = "your-node-ip"

# Panel Connection
PANEL_URL = "http://your-panel-ip:5000"
API_KEY = "your-node-api-key"

# Container Settings
DEFAULT_STORAGE_POOL = "default"
DEFAULT_TEMPLATE = "ubuntu:22.04"

# Monitoring
UPDATE_INTERVAL = 30  # seconds
LOG_LEVEL = "INFO"

# Security
ALLOWED_NETWORKS = ["127.0.0.1", "your-panel-ip"]
MAX_CONTAINERS = 50
```

---

## ⚙️ Configuration

### Panel Configuration Files

1. **Main Config** (`config.py` in panel root):
```python
import os

# Panel Settings
PANEL_NAME = os.getenv('PANEL_NAME', 'AVM Panel')
SECRET_KEY = os.getenv('SECRET_KEY', 'your-secret-key')
DEBUG_MODE = os.getenv('DEBUG_MODE', 'False')
HOST = os.getenv('HOST', '127.0.0.1')
PORT = int(os.getenv('PORT', 5000))

# Database
DATABASE_PATH = os.getenv('DATABASE_PATH', 'avm.db')

# Server Settings
YOUR_SERVER_IP = os.getenv('YOUR_SERVER_IP', '127.0.0.1')
DEFAULT_STORAGE_POOL = os.getenv('DEFAULT_STORAGE_POOL', 'default')
```

2. **Database Config**:
```python
# Database initialization
DATABASE_PATH = 'avm.db'

def init_db():
    """Initialize database with all tables"""
    # Tables will be created automatically on first run
    pass
```

### Node Configuration Files

1. **Node Config** (`config.py` in node directory):
```python
# Node identification
NODE_ID = "node-1"
NODE_NAME = "Primary Node"
NODE_LOCATION = "Datacenter 1"
NODE_IP = "192.168.1.100"

# Panel connection
PANEL_URL = "http://192.168.1.10:5000"
API_KEY = "your-secure-api-key"

# Container settings
DEFAULT_TEMPLATE = "ubuntu:22.04"
DEFAULT_STORAGE_POOL = "default"
MAX_CONTAINERS = 100
```

---

## 🚀 Starting the Services

### Starting AVM Panel

#### Method 1: Direct Python
```bash
# Navigate to panel directory
cd avm-panel

# Activate virtual environment
# Windows:
venv\Scripts\activate
# Linux:
source venv/bin/activate

# Start the panel
python avm.py
```

#### Method 2: Using Gunicorn (Production)
```bash
# Install gunicorn
pip install gunicorn

# Start with gunicorn
gunicorn -w 4 -b 0.0.0.0:5000 avm:app
```

#### Method 3: Using systemd (Linux)
```bash
# Create systemd service
sudo nano /etc/systemd/system/avm-panel.service
```

```ini
[Unit]
Description=AVM Panel
After=network.target

[Service]
Type=simple
User=avm
WorkingDirectory=/opt/avm-panel
Environment=PATH=/opt/avm-panel/venv/bin
ExecStart=/opt/avm-panel/venv/bin/python avm.py
Restart=always

[Install]
WantedBy=multi-user.target
```

```bash
# Enable and start service
sudo systemctl enable avm-panel
sudo systemctl start avm-panel
sudo systemctl status avm-panel
```

### Starting AVM Node

#### Method 1: Direct Python
```bash
# Navigate to node directory
cd avm-node

# Activate virtual environment
source venv/bin/activate

# Start the node
python node.py
```

#### Method 2: Using systemd (Linux)
```bash
# Create systemd service
sudo nano /etc/systemd/system/avm-node.service
```

```ini
[Unit]
Description=AVM Node
After=network.target

[Service]
Type=simple
User=avm
WorkingDirectory=/opt/avm-node
Environment=PATH=/opt/avm-node/venv/bin
ExecStart=/opt/avm-node/venv/bin/python node.py
Restart=always

[Install]
WantedBy=multi-user.target
```

```bash
# Enable and start service
sudo systemctl enable avm-node
sudo systemctl start avm-node
sudo systemctl status avm-node
```

---

## 🔧 Troubleshooting

### Common Issues

#### 1. Port Already in Use
```bash
# Check what's using the port
netstat -tulpn | grep :5000
# or
lsof -i :5000

# Kill the process
sudo kill -9 <PID>

# Or change port in config
PORT=5001
```

#### 2. Database Permission Issues
```bash
# Check database permissions
ls -la avm.db

# Fix permissions
chmod 664 avm.db
chown $USER:$USER avm.db
```

#### 3. LXC/LXD Issues (Linux)
```bash
# Check LXD status
sudo systemctl status lxd

# Initialize LXD if needed
sudo lxd init --auto

# Check user permissions
groups $USER | grep lxd
```

#### 4. Python Dependencies
```bash
# Reinstall dependencies
pip install -r requirements.txt --force-reinstall

# Clear pip cache
pip cache purge
```

#### 5. Node Connection Issues
```bash
# Test network connectivity
ping <panel-ip>
telnet <panel-ip> 5000

# Check firewall settings
sudo ufw status
sudo firewall-cmd --list-all
```

### Log Files

#### Panel Logs:
```bash
# View panel logs
tail -f avm.log

# Check for errors
grep ERROR avm.log
```

#### Node Logs:
```bash
# View node logs
tail -f node.log

# Check for connection issues
grep "connection" node.log
```

### Performance Issues

#### 1. High Memory Usage
```bash
# Check memory usage
htop
# or
free -h

# Restart services if needed
sudo systemctl restart avm-panel
```

#### 2. Slow Database
```bash
# Check database size
ls -lh avm.db

# Optimize database
sqlite3 avm.db "VACUUM;"
```

---

## 🔒 Security Recommendations

### 1. Firewall Configuration
```bash
# UFW (Ubuntu)
sudo ufw allow 22/tcp
sudo ufw allow 5000/tcp
sudo ufw enable

# iptables
sudo iptables -A INPUT -p tcp --dport 5000 -j ACCEPT
```

### 2. SSL/TLS Setup
```bash
# Install certbot
sudo apt install certbot python3-certbot-nginx -y

# Get SSL certificate
sudo certbot --nginx -d your-domain.com
```

### 3. API Key Security
- Use strong, random API keys
- Rotate keys regularly
- Store keys in environment variables
- Never commit keys to version control

### 4. Database Security
```bash
# Set proper permissions
chmod 660 avm.db
chown avm:avm avm.db

# Enable database encryption
sqlite3 avm.db "PRAGMA key = 'your-encryption-key';"
```

### 5. Network Security
- Use VPN for remote access
- Implement IP whitelisting
- Use reverse proxy (nginx/apache)
- Enable fail2ban for brute force protection

---

## 📞 Support

### Getting Help
1. **Check Logs**: Always check log files first
2. **Documentation**: Read this guide thoroughly
3. **Community**: Join our Discord/Telegram community
4. **Issues**: Report bugs on GitHub

### Useful Commands
```bash
# Check service status
sudo systemctl status avm-panel
sudo systemctl status avm-node

# View logs
sudo journalctl -u avm-panel -f
sudo journalctl -u avm-node -f

# Restart services
sudo systemctl restart avm-panel
sudo systemctl restart avm-node

# Check ports
netstat -tulpn | grep -E ':(5000|8080)'
```

---

## 🎉 Next Steps

After successful installation:

1. **Access Panel**: Open `http://your-ip:5000` in your browser
2. **Create Admin Account**: Register first user (automatically becomes admin)
3. **Add Nodes**: Connect your nodes to the panel
4. **Create Templates**: Set up container templates
5. **Monitor Performance**: Check system resources and logs
6. **Backup Regularly**: Set up automated backups

---

## 📝 Notes

- This guide assumes basic Linux/Windows administration knowledge
- Always backup data before making changes
- Test in development environment before production deployment
- Keep software updated regularly
- Monitor system resources and performance

For additional help, visit our documentation or contact support.
