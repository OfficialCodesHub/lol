# Auto Local Node Feature Guide

## 🎯 Overview

The Auto Local Node feature automatically detects when the AVM Panel is installed on a VPS and creates a local node that uses the same VPS resources (CPU, RAM, Disk). This provides seamless integration and immediate access to container management capabilities.

## 🚀 How It Works

### 1. VPS Detection
The system automatically detects if the panel is running on a VPS by checking:
- Virtualization indicators (VMware, VirtualBox, KVM, Xen, Hyper-V)
- VPS provider signatures (DigitalOcean, Vultr, Linode, AWS, Google Cloud, Azure, Oracle)
- Cloud-init presence
- VPS environment variables
- Public IP addresses
- Common VPS port availability

### 2. Local Node Creation
When VPS environment is detected:
- Creates a local node entry in the database
- Automatically configures node with system resources
- Sets node status to "online"
- Creates sample containers for demonstration

### 3. Resource Monitoring
The system continuously monitors:
- CPU usage and core count
- Memory usage and total available
- Disk usage and total capacity
- Network statistics
- System uptime

## 📋 Features

### ✨ Automatic Features
- **VPS Detection**: Automatically identifies VPS environments
- **Resource Monitoring**: Real-time system resource tracking
- **Node Management**: Automatic local node creation and configuration
- **Sample Containers**: Creates demonstration containers
- **Status Updates**: Continuous node status monitoring
- **Historical Data**: Stores resource usage history

### 🔧 Configuration Options
- **Detection Sensitivity**: Configurable VPS detection thresholds
- **Monitoring Intervals**: Adjustable resource update frequency
- **Sample Data**: Optional sample container creation
- **Logging**: Comprehensive logging system

## 🛠️ Installation & Setup

### Prerequisites
- AVM Panel installed on a VPS
- Python 3.8+
- Required dependencies (automatically installed)

### Automatic Setup
1. Install AVM Panel on VPS following standard installation guide
2. Start the panel: `python avm.py`
3. The auto local node service starts automatically
4. Check logs: `tail -f auto_node.log`

### Manual Verification
```bash
# Check if local node was created
python -c "
import sqlite3
conn = sqlite3.connect('avm.db')
cursor = conn.cursor()
cursor.execute('SELECT * FROM nodes WHERE id LIKE \"local%\"')
print(cursor.fetchall())
conn.close()
"
```

## 📊 Database Schema

### Nodes Table
```sql
CREATE TABLE nodes (
    id TEXT PRIMARY KEY,           -- Local node ID (e.g., 'local-node-1')
    name TEXT NOT NULL,            -- Node display name
    location TEXT NOT NULL,       -- Node location
    ip TEXT NOT NULL,             -- Public IP address
    status TEXT NOT NULL,         -- Node status (online/offline)
    created_at TEXT NOT NULL,     -- Creation timestamp
    updated_at TEXT NOT NULL,     -- Last update timestamp
    cpu_cores INTEGER,            -- Number of CPU cores
    memory_mb INTEGER,            -- Total memory in MB
    disk_gb INTEGER,              -- Total disk space in GB
    cpu_usage REAL DEFAULT 0,     -- Current CPU usage percentage
    memory_usage REAL DEFAULT 0,  -- Current memory usage percentage
    disk_usage REAL DEFAULT 0,   -- Current disk usage percentage
    api_key TEXT,                 -- API key for node communication
    last_seen TEXT                -- Last time node was seen
);
```

### Containers Table
```sql
CREATE TABLE containers (
    id TEXT PRIMARY KEY,          -- Container ID
    name TEXT NOT NULL,           -- Container display name
    node_id TEXT NOT NULL,       -- Parent node ID
    os_template TEXT NOT NULL,    -- OS template (e.g., 'ubuntu:22.04')
    cpu_cores INTEGER DEFAULT 1, -- Allocated CPU cores
    memory_mb INTEGER DEFAULT 1024, -- Allocated memory in MB
    disk_gb INTEGER DEFAULT 20,   -- Allocated disk space in GB
    status TEXT NOT NULL DEFAULT 'stopped', -- Container status
    created_at TEXT NOT NULL,     -- Creation timestamp
    updated_at TEXT NOT NULL      -- Last update timestamp
);
```

### Node Stats Table
```sql
CREATE TABLE node_stats (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    node_id TEXT NOT NULL,        -- Node ID
    cpu_usage REAL NOT NULL,      -- CPU usage percentage
    memory_usage REAL NOT NULL,   -- Memory usage percentage
    disk_usage REAL NOT NULL,     -- Disk usage percentage
    network_rx INTEGER DEFAULT 0, -- Network received bytes
    network_tx INTEGER DEFAULT 0, -- Network transmitted bytes
    timestamp TEXT NOT NULL       -- Timestamp of measurement
);
```

## 🔍 Monitoring & Logs

### Log Files
- **auto_node.log**: Main auto node service logs
- **avm.log**: Main application logs

### Log Levels
- **INFO**: Normal operation messages
- **WARNING**: Non-critical issues
- **ERROR**: Critical errors
- **DEBUG**: Detailed debugging information

### Key Log Messages
```
INFO - VPS environment detected, creating local node...
INFO - Local node created successfully: local-node-1
INFO - Created 2 sample containers
INFO - Starting resource monitoring loop...
DEBUG - Local node status updated
```

## ⚙️ Configuration

### Environment Variables
```env
# Auto Node Configuration
AUTO_NODE_ENABLED=true                    # Enable/disable auto node
AUTO_NODE_DETECTION_SENSITIVITY=2         # Detection sensitivity (1-3)
AUTO_NODE_MONITOR_INTERVAL=30             # Monitoring interval in seconds
AUTO_NODE_CREATE_SAMPLES=true             # Create sample containers
AUTO_NODE_LOG_LEVEL=INFO                  # Log level
```

### Advanced Configuration
```python
# In auto_local_node.py
class VPSDetector:
    @staticmethod
    def is_vps_environment():
        # Custom detection logic can be added here
        pass

class SystemResourceMonitor:
    @staticmethod
    def get_system_info():
        # Custom resource monitoring can be added here
        pass
```

## 🎛️ API Integration

### Node Status API
```http
GET /api/nodes/{node_id}
Content-Type: application/json

Response:
{
    "id": "local-node-1",
    "name": "Local Node",
    "status": "online",
    "cpu_usage": 25.5,
    "memory_usage": 60.2,
    "disk_usage": 45.8,
    "last_seen": "2026-04-06T12:00:00Z"
}
```

### Container Management API
```http
GET /api/containers?node_id=local-node-1
Content-Type: application/json

Response:
{
    "containers": [
        {
            "id": "local-node-1-web-1",
            "name": "Web Server 1",
            "status": "running",
            "cpu_cores": 1,
            "memory_mb": 1024,
            "disk_gb": 20
        }
    ]
}
```

## 🔧 Troubleshooting

### Common Issues

#### 1. Local Node Not Created
**Symptoms**: No local node appears in dashboard
**Causes**: 
- Not running on VPS
- Detection sensitivity too low
- Database permission issues

**Solutions**:
```bash
# Check if running on VPS
python -c "
from auto_local_node import VPSDetector
print('VPS detected:', VPSDetector.is_vps_environment())
"

# Increase detection sensitivity
export AUTO_NODE_DETECTION_SENSITIVITY=1

# Check database permissions
ls -la avm.db
```

#### 2. Resource Monitoring Not Working
**Symptoms**: Node shows 0% resource usage
**Causes**: 
- psutil not installed
- Permission issues
- System monitoring disabled

**Solutions**:
```bash
# Install psutil
pip install psutil

# Check permissions
python -c "
import psutil
print('CPU:', psutil.cpu_percent())
print('Memory:', psutil.virtual_memory().percent)
"
```

#### 3. Sample Containers Not Created
**Symptoms**: No sample containers appear
**Causes**: 
- Sample creation disabled
- Database errors
- Insufficient permissions

**Solutions**:
```bash
# Enable sample creation
export AUTO_NODE_CREATE_SAMPLES=true

# Manually create samples
python -c "
from auto_local_node import LocalNodeManager
manager = LocalNodeManager()
manager.create_local_containers()
"
```

### Debug Mode
```bash
# Enable debug logging
export AUTO_NODE_LOG_LEVEL=DEBUG

# Run with verbose output
python auto_local_node.py
```

## 🚀 Performance Considerations

### Resource Usage
- **CPU**: < 1% for monitoring
- **Memory**: < 50MB for the service
- **Disk**: Minimal (logs only)
- **Network**: < 1MB/day for IP checks

### Optimization Tips
1. **Adjust Monitoring Interval**: Increase from 30s to 60s for lower resource usage
2. **Disable Sample Creation**: Set `AUTO_NODE_CREATE_SAMPLES=false`
3. **Log Rotation**: Implement log rotation for long-running instances
4. **Database Optimization**: Regular VACUUM operations

## 🔒 Security Considerations

### Data Protection
- No sensitive data transmitted externally
- All monitoring data stored locally
- API keys generated securely
- Database encryption recommended

### Access Control
- Local node accessible only to admin users
- API endpoints protected by authentication
- Resource monitoring limited to system stats
- No container command execution without authorization

### Recommendations
1. **Database Encryption**: Enable SQLite encryption
2. **API Key Rotation**: Regularly update API keys
3. **Access Logging**: Monitor access to local node APIs
4. **Network Security**: Use firewall to restrict access

## 📈 Usage Examples

### Basic Usage
```python
# Check if local node exists
from auto_local_node import LocalNodeManager
manager = LocalNodeManager()

# Get system info
info = SystemResourceMonitor.get_system_info()
print(f"CPU: {info['cpu']['cores']} cores")
print(f"Memory: {info['memory']['total_mb']} MB")
print(f"Disk: {info['disk']['total_gb']} GB")
```

### Advanced Monitoring
```python
# Monitor node status continuously
import time
from auto_local_node import AutoNodeService

service = AutoNodeService()
while True:
    service.node_manager.update_node_status()
    time.sleep(30)
```

### Custom Detection
```python
# Add custom VPS detection logic
class CustomVPSDetector(VPSDetector):
    @staticmethod
    def is_vps_environment():
        # Add custom detection methods
        return super().is_vps_environment() or custom_check()
```

## 🎯 Best Practices

### Production Deployment
1. **Enable Logging**: Set appropriate log levels
2. **Monitor Resources**: Track service resource usage
3. **Regular Backups**: Backup database regularly
4. **Security Updates**: Keep dependencies updated

### Development Environment
1. **Debug Mode**: Enable detailed logging
2. **Testing**: Test detection logic thoroughly
3. **Mock Data**: Use sample data for development
4. **Documentation**: Document custom configurations

## 📞 Support

### Getting Help
1. **Check Logs**: Review auto_node.log for errors
2. **Verify Environment**: Ensure running on VPS
3. **Test Connectivity**: Check database access
4. **Review Configuration**: Verify environment variables

### Common Commands
```bash
# Check service status
ps aux | grep auto_local_node

# View logs
tail -f auto_node.log

# Test detection
python -c "from auto_local_node import VPSDetector; print(VPSDetector.is_vps_environment())"

# Monitor resources
python -c "from auto_local_node import SystemResourceMonitor; print(SystemResourceMonitor.get_system_info())"
```

---

## 🎉 Conclusion

The Auto Local Node feature provides seamless integration between AVM Panel and VPS environments, automatically creating a local node that utilizes the same system resources. This eliminates the need for manual node configuration and provides immediate access to container management capabilities.

The system is designed to be:
- **Automatic**: Detects VPS environments and configures nodes automatically
- **Efficient**: Minimal resource usage and overhead
- **Secure**: All data stored locally with proper access controls
- **Scalable**: Can handle multiple nodes and containers
- **Reliable**: Continuous monitoring and status updates

For additional support or questions, refer to the main AVM Panel documentation or contact support.
