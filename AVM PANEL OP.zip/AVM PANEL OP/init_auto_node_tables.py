#!/usr/bin/env python3
"""
Initialize database tables for auto local node functionality
"""

import sqlite3
import os
from datetime import datetime

def init_auto_node_tables():
    """Initialize tables for auto local node functionality"""
    
    db_path = os.getenv('DATABASE_PATH', 'avm.db')
    
    try:
        with sqlite3.connect(db_path) as conn:
            cursor = conn.cursor()
            
            # Create nodes table if not exists
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS nodes (
                    id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    location TEXT NOT NULL,
                    ip TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'offline',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    cpu_cores INTEGER,
                    memory_mb INTEGER,
                    disk_gb INTEGER,
                    cpu_usage REAL DEFAULT 0,
                    memory_usage REAL DEFAULT 0,
                    disk_usage REAL DEFAULT 0,
                    api_key TEXT,
                    last_seen TEXT
                )
            ''')
            
            # Create containers table if not exists
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS containers (
                    id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    node_id TEXT NOT NULL,
                    os_template TEXT NOT NULL,
                    cpu_cores INTEGER DEFAULT 1,
                    memory_mb INTEGER DEFAULT 1024,
                    disk_gb INTEGER DEFAULT 20,
                    status TEXT NOT NULL DEFAULT 'stopped',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    FOREIGN KEY (node_id) REFERENCES nodes (id) ON DELETE CASCADE
                )
            ''')
            
            # Create node_stats table for historical data
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS node_stats (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    node_id TEXT NOT NULL,
                    cpu_usage REAL NOT NULL,
                    memory_usage REAL NOT NULL,
                    disk_usage REAL NOT NULL,
                    network_rx INTEGER DEFAULT 0,
                    network_tx INTEGER DEFAULT 0,
                    timestamp TEXT NOT NULL,
                    FOREIGN KEY (node_id) REFERENCES nodes (id) ON DELETE CASCADE
                )
            ''')
            
            # Create indexes for better performance
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_nodes_status ON nodes (status)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_containers_node_id ON containers (node_id)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_containers_status ON containers (status)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_node_stats_node_id ON node_stats (node_id)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_node_stats_timestamp ON node_stats (timestamp)')
            
            conn.commit()
            print("✅ Auto node tables initialized successfully!")
            
            # Check if local node already exists
            cursor.execute('SELECT id FROM nodes WHERE id = ?', ('local-node-1',))
            if not cursor.fetchone():
                print("📝 Local node not found - will be created automatically when panel starts on VPS")
            else:
                print("ℹ️ Local node already exists")
            
            return True
            
    except Exception as e:
        print(f"❌ Error initializing auto node tables: {e}")
        return False

if __name__ == "__main__":
    init_auto_node_tables()
